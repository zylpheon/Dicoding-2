import "./css/style.css";
import "./script/loading-indicator.js";
import "./script/notes.js";
